import StoreManagerDashboard from './components/store-manager/StoreManagerDashboard';
import SuperAdminDashboard from './components/superadmin/SuperAdminDashboard';
import React, { useState, useEffect } from 'react';
import { 
  User, 
  Lock, 
  ArrowLeft, 
  ArrowRight, 
  Check, 
  Store, 
  Truck, 
  AlertCircle, 
  Info, 
  CheckCircle, 
  LogOut, 
  ShieldCheck, 
  Building2, 
  CreditCard, 
  FileText, 
  Database, 
  Globe, 
  Layers, 
  TrendingUp, 
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { SupplierDashboard } from './components/supplier/SupplierDashboard';

// Shaba validation function
function formatAndValidateShaba(input: string): { isValid: boolean; formatted?: string; error?: string } {
  let clean = input.toUpperCase().replace(/[\s-]/g, '');
  if (!clean.startsWith('IR')) {
    clean = 'IR' + clean;
  }
  const numericPart = clean.substring(2);
  if (numericPart.length !== 24 || !/^\d{24}$/.test(numericPart)) {
    return { isValid: false, error: 'شماره شبا باید دقیقاً شامل ۲۴ رقم عددی باشد.' };
  }
  return { isValid: true, formatted: clean };
}

export default function App() {
  // Navigation states
  // 'login' | 'role_select' | 'supplier_form' | 'store_manager_form' | 'dashboard'
  const [view, setView] = useState<'login' | 'role_select' | 'supplier_form' | 'store_manager_form' | 'dashboard'>('login');
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [loading, setLoading] = useState(false);
  const [registerError, setRegisterError] = useState<string | null>(null);

  // Auto-login if token exists
  useEffect(() => {
    if (token) {
      // In a real app we'd fetch profile. Let's decode or trust token for demonstration.
      try {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
          setCurrentUser(JSON.parse(storedUser));
          setView('dashboard');
        }
      } catch (e) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
  }, [token]);

  const showNotification = (message: string, type: 'success' | 'error') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 5000);
  };

  // Login form state
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Supplier form state (5 steps)
  const [supplierStep, setSupplierStep] = useState(1);
  const [supplierData, setSupplierData] = useState({
    firstName: '',
    lastName: '',
    mobile: '',
    email: '',
    brandName: '',
    activityType: 'PRODUCER', // PRODUCER, WHOLESALER, IMPORTER, OTHER
    address: '',
    province: '',
    city: '',
    postalCode: '',
    telephone: '',
    website: '',
    nationalCode: '',
    accountHolderName: '',
    shaba: 'IR',
    bankName: '',
    termsAccepted: false,
    agreementVersion: '',
    agreementAcceptedAt: '',
    username: '',
    password: '',
    confirmPassword: ''
  });

  // Store Manager form state (4 steps)
  const [storeStep, setStoreStep] = useState(1);
  const [storeData, setStoreData] = useState({
    firstName: '',
    lastName: '',
    mobile: '',
    email: '',
    storeName: '',
    storeUrl: '',
    platformType: 'WOOCOMMERCE', // WOOCOMMERCE, SHOPIFY, OTHER
    fieldOfActivity: '',
    productCount: '',
    username: '',
    password: '',
    confirmPassword: ''
  });

  const [showTermsModal, setShowTermsModal] = useState(false);
  const [termsReadProgress, setTermsReadProgress] = useState(false);

  // Handle Login submission
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUsername || !loginPassword) {
      showNotification('لطفاً نام کاربری و رمز عبور را وارد کنید.', 'error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUsername, password: loginPassword })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'خطایی رخ داد.');
      }

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setToken(data.token);
      setCurrentUser(data.user);
      showNotification('ورود با موفقیت انجام شد.', 'success');
      setView('dashboard');
    } catch (err: any) {
      showNotification(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Handle Supplier register
  const handleSupplierRegister = async () => {
    // Basic account validations
    if (!supplierData.username || !supplierData.password) {
      showNotification('لطفاً نام کاربری و رمز عبور را تکمیل کنید.', 'error');
      return;
    }
    if (supplierData.password !== supplierData.confirmPassword) {
      showNotification('رمز عبور و تکرار آن یکسان نیستند.', 'error');
      return;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(supplierData.username)) {
      showNotification('نام کاربری فقط می‌تواند شامل حروف انگلیسی، اعداد و خط تیره باشد.', 'error');
      return;
    }

    setLoading(true);
    setRegisterError(null);
    try {
      // Map frontend state to backend expected format
      const payload = {
        ...supplierData,
        agreementAccepted: supplierData.termsAccepted
      };

      const response = await fetch('/api/auth/register/supplier', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'خطا در ثبت‌نام تامین‌کننده');
      }

      // 2. JWT token and user logic
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setToken(data.token);
      setCurrentUser(data.user);
      
      showNotification('ثبت‌نام شما به عنوان تامین‌کننده با موفقیت انجام شد.', 'success');
      
      // 3. Redirect / update browser history to supplier dashboard
      window.history.pushState({}, '', '/supplier/dashboard');
      setView('dashboard');
    } catch (err: any) {
      setRegisterError(err.message);
      showNotification(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Handle Store Manager register
  const handleStoreManagerRegister = async () => {
    if (!storeData.username || !storeData.password) {
      showNotification('لطفاً نام کاربری و رمز عبور را تکمیل کنید.', 'error');
      return;
    }
    if (storeData.password !== storeData.confirmPassword) {
      showNotification('رمز عبور و تکرار آن یکسان نیستند.', 'error');
      return;
    }
    if (!/^[a-zA-Z0-9_]+$/.test(storeData.username)) {
      showNotification('نام کاربری فقط می‌تواند شامل حروف انگلیسی، اعداد و خط تیره باشد.', 'error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/auth/register/store-manager', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(storeData)
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'خطا در ثبت‌نام مدیر فروشگاه');
      }

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setToken(data.token);
      setCurrentUser(data.user);
      showNotification('ثبت‌نام شما به عنوان مدیر فروشگاه با موفقیت انجام شد.', 'success');
      setView('dashboard');
    } catch (err: any) {
      showNotification(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setCurrentUser(null);
    setView('login');
    showNotification('با موفقیت خارج شدید.', 'success');
  };

  // Province and Cities mock list
  const PROVINCES = [
    { name: 'تهران', cities: ['تهران', 'ری', 'پردیس', 'شهریار', 'اسلامشهر'] },
    { name: 'اصفهان', cities: ['اصفهان', 'کاشان', 'خمینی‌شهر', 'نجف‌آباد'] },
    { name: 'خراسان رضوی', cities: ['مشهد', 'نیشابور', 'سبزوار', 'تربت حیدریه'] },
    { name: 'فارس', cities: ['شیراز', 'مرودشت', 'کازرون', 'جهرم'] },
    { name: 'آذربایجان شرقی', cities: ['تبریز', 'مراغه', 'مرند', 'میانه'] }
  ];

  const getCitiesForProvince = (provName: string) => {
    return PROVINCES.find(p => p.name === provName)?.cities || [];
  };

  // Dashboard Views
  if (view === 'dashboard') {
    if (currentUser?.role === 'SUPPLIER') {
      return <SupplierDashboard user={currentUser} onLogout={logout} showNotification={showNotification} />;
    } else if (currentUser?.role === 'STORE_MANAGER') {
      return <StoreManagerDashboard user={currentUser} onLogout={logout} />;
    } else if (currentUser?.role === 'SUPER_ADMIN') {
      return <SuperAdminDashboard user={currentUser} onLogout={logout} />;
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col justify-between" dir="rtl">
      
      {/* Top Banner & Notifications */}
      {notification && (
        <div id="notification-banner" className={`fixed top-4 left-4 right-4 md:left-auto md:w-96 z-50 p-4 rounded-xl shadow-lg border transition-all transform duration-300 flex items-start gap-3 animate-slide-in ${
          notification.type === 'success' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-900' 
            : 'bg-rose-50 border-rose-200 text-rose-900'
        }`}>
          {notification.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          )}
          <div className="text-sm font-medium leading-relaxed">
            {notification.message}
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-4xl bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden flex flex-col md:flex-row min-h-[600px] transition-all duration-300">
          
          {/* Decorative Sidebar */}
          <div id="decor-sidebar" className="md:w-1/3 bg-slate-900 text-white p-8 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-950 opacity-90 z-0" />
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-indigo-500 rounded-full blur-3xl opacity-20" />
            
            <div className="relative z-10 flex flex-col items-center md:items-start text-center md:text-right">
              {/* Logo */}
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-6 border border-white/20 shadow-inner">
                <Layers className="w-6 h-6 text-indigo-400" />
              </div>
              <h1 className="text-xl font-bold tracking-tight mb-2">بازارگاه تامین و توزیع</h1>
              <p className="text-sm text-slate-300 leading-relaxed font-light">
                پلتفرم یکپارچه و هوشمند واسط میان تولیدکنندگان، تامین‌کنندگان سراسر کشور و فروشگاه‌های آنلاین و فیزیکی.
              </p>
            </div>

            <div className="relative z-10 mt-8 hidden md:block">
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-xs text-slate-300">
                  <div className="w-6 h-6 rounded-lg bg-indigo-500/10 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <span>تامین زنجیره توزیع به سراسر کشور</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-300">
                  <div className="w-6 h-6 rounded-lg bg-indigo-500/10 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <span>اتصال مستقیم به WooCommerce و Shopify</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-300">
                  <div className="w-6 h-6 rounded-lg bg-indigo-500/10 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <span>تسویه حساب اتوماتیک و امنیت مالی بالا</span>
                </div>
              </div>
            </div>

            <div className="relative z-10 text-xs text-slate-400 text-center md:text-right mt-6">
              نسخه ۱.۰.۰ • امنیت تایید شده
            </div>
          </div>

          {/* Form Content Body */}
          <div id="form-body" className="flex-1 p-6 md:p-10 flex flex-col justify-center">
            
            {/* 1. LOGIN VIEW */}
            {view === 'login' && (
              <div id="view-login" className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-1">خوش آمدید</h2>
                  <p className="text-slate-500 text-sm">لطفاً برای ورود به پنل کاربری اطلاعات خود را وارد کنید.</p>
                </div>

                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام کاربری (Username)</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        value={loginUsername}
                        onChange={(e) => setLoginUsername(e.target.value)}
                        placeholder="نام کاربری انگلیسی خود را وارد کنید"
                        className="w-full pl-3 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors text-left"
                        style={{ direction: 'ltr' }}
                      />
                      <User className="w-5 h-5 text-slate-400 absolute top-3.5 right-3" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">کلمه عبور (Password)</label>
                    <div className="relative">
                      <input 
                        type={showLoginPassword ? 'text' : 'password'} 
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors text-left"
                        style={{ direction: 'ltr' }}
                      />
                      <Lock className="w-5 h-5 text-slate-400 absolute top-3.5 right-3" />
                      <button 
                        type="button" 
                        onClick={() => setShowLoginPassword(!showLoginPassword)}
                        className="absolute top-3.5 left-3 text-slate-400 hover:text-slate-600"
                      >
                        {showLoginPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <label className="flex items-center gap-2 cursor-pointer text-slate-600">
                      <input type="checkbox" className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 w-4 h-4" />
                      <span>مرا به خاطر بسپار</span>
                    </label>
                    <button 
                      type="button" 
                      onClick={() => showNotification('بخش بازیابی کلمه عبور به زودی فعال خواهد شد.', 'success')} 
                      className="text-indigo-600 hover:underline font-medium"
                    >
                      فراموشی رمز عبور؟
                    </button>
                  </div>

                  <button 
                    type="submit" 
                    disabled={loading}
                    className="w-full bg-slate-900 text-white font-medium py-3 px-4 rounded-xl hover:bg-slate-850 active:bg-slate-950 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all flex items-center justify-center gap-2 shadow-sm text-sm"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        در حال بررسی...
                      </span>
                    ) : (
                      'ورود به حساب کاربری'
                    )}
                  </button>
                </form>

                <div className="relative flex py-2 items-center">
                  <div className="flex-grow border-t border-slate-200"></div>
                  <span className="flex-shrink mx-4 text-slate-400 text-xs">یا هنوز ثبت‌نام نکرده‌اید؟</span>
                  <div className="flex-grow border-t border-slate-200"></div>
                </div>

                <button 
                  onClick={() => setView('role_select')}
                  className="w-full bg-white border border-slate-200 text-slate-800 font-medium py-3 px-4 rounded-xl hover:bg-slate-50 transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  ایجاد حساب جدید
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            )}


            {/* 2. ROLE SELECTION VIEW */}
            {view === 'role_select' && (
              <div id="view-role-select" className="space-y-6 animate-fade-in">
                <div>
                  <button 
                    onClick={() => setView('login')}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 mb-4 font-medium transition-colors"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    بازگشت به صفحه ورود
                  </button>
                  <h2 className="text-2xl font-bold text-slate-900 mb-1">ثبت‌نام در پلتفرم بازارگاه</h2>
                  <p className="text-slate-500 text-sm">لطفاً ابتدا نقش کسب‌وکار خود را انتخاب نمایید تا فرم ثبت‌نام مربوطه نمایش داده شود.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  
                  {/* Card Supplier */}
                  <button 
                    onClick={() => setView('supplier_form')}
                    className="text-right p-6 rounded-2xl border-2 border-slate-100 hover:border-indigo-500 hover:shadow-md transition-all flex flex-col justify-between group h-64 focus:outline-none"
                  >
                    <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <Truck className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">ثبت‌نام به عنوان تامین‌کننده</h3>
                      <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
                        اگر تولیدکننده، عمده‌فروش، واردکننده یا انباردار هستید و تمایل دارید محصولات خود را به هزاران فروشگاه عرضه کنید.
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-indigo-600 font-semibold mt-4">
                      <span>شروع ثبت‌نام تامین‌کننده</span>
                      <ArrowLeft className="w-3.5 h-3.5 transform group-hover:-translate-x-1 transition-transform" />
                    </div>
                  </button>

                  {/* Card Store Manager */}
                  <button 
                    onClick={() => setView('store_manager_form')}
                    className="text-right p-6 rounded-2xl border-2 border-slate-100 hover:border-indigo-500 hover:shadow-md transition-all flex flex-col justify-between group h-64 focus:outline-none"
                  >
                    <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <Store className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg group-hover:text-emerald-600 transition-colors">ثبت‌نام به عنوان مدیر فروشگاه</h3>
                      <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
                        اگر دارای فروشگاه اینترنتی (سایت مستقل، اینستاگرام) یا فیزیکی هستید و مایلید محصولات باکیفیت را مستقیماً تامین کنید.
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-emerald-600 font-semibold mt-4">
                      <span>شروع ثبت‌نام فروشگاه</span>
                      <ArrowLeft className="w-3.5 h-3.5 transform group-hover:-translate-x-1 transition-transform" />
                    </div>
                  </button>

                </div>
              </div>
            )}


            {/* 3. SUPPLIER MULTI-STEP FORM */}
            {view === 'supplier_form' && (
              <div id="view-supplier-form" className="space-y-6 animate-fade-in">
                
                {/* Header & Back */}
                <div className="flex items-center justify-between">
                  <button 
                    onClick={() => {
                      if (supplierStep > 1) {
                        setSupplierStep(supplierStep - 1);
                      } else {
                        setView('role_select');
                      }
                    }}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-medium transition-colors"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    {supplierStep === 1 ? 'بازگشت به انتخاب نقش' : 'مرحله قبل'}
                  </button>
                  <span className="text-xs font-semibold text-slate-400">نقش: تامین‌کننده</span>
                </div>

                {/* Progress Indicators */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span className="font-semibold text-indigo-600">مرحله {supplierStep} از ۵</span>
                    <span>
                      {supplierStep === 1 && 'اطلاعات شخصی'}
                      {supplierStep === 2 && 'اطلاعات کسب‌وکار و صنف'}
                      {supplierStep === 3 && 'اطلاعات مالی و بانکی'}
                      {supplierStep === 4 && 'قوانین و مقررات'}
                      {supplierStep === 5 && 'ایجاد حساب کاربری'}
                    </span>
                  </div>
                  {/* Step bar */}
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex flex-row-reverse">
                    <div 
                      className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                      style={{ width: `${(supplierStep / 5) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Form Step Contents */}
                <div className="space-y-4">
                  
                  {/* STEP 1: Personal Info */}
                  {supplierStep === 1 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام *</label>
                          <input 
                            type="text" 
                            required
                            value={supplierData.firstName}
                            onChange={(e) => setSupplierData({...supplierData, firstName: e.target.value})}
                            placeholder="نام خود را وارد کنید"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام خانوادگی *</label>
                          <input 
                            type="text" 
                            required
                            value={supplierData.lastName}
                            onChange={(e) => setSupplierData({...supplierData, lastName: e.target.value})}
                            placeholder="نام خانوادگی خود را وارد کنید"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">شماره موبایل *</label>
                          <input 
                            type="tel" 
                            required
                            value={supplierData.mobile}
                            onChange={(e) => setSupplierData({...supplierData, mobile: e.target.value})}
                            placeholder="مثال: 09123456789"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                          <p className="text-[10px] text-slate-400 mt-1">شماره تماس اصلی و معتبر جهت احراز هویت پیامکی.</p>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">کد ملی *</label>
                          <input 
                            type="text" 
                            required
                            value={supplierData.nationalCode}
                            onChange={(e) => setSupplierData({...supplierData, nationalCode: e.target.value})}
                            placeholder="کد ملی ده رقمی بدون خط تیره"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">آدرس ایمیل (اختیاری)</label>
                        <input 
                          type="email" 
                          value={supplierData.email}
                          onChange={(e) => setSupplierData({...supplierData, email: e.target.value})}
                          placeholder="example@gmail.com"
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left"
                          style={{ direction: 'ltr' }}
                        />
                      </div>

                      <button 
                        onClick={() => {
                          if (!supplierData.firstName || !supplierData.lastName || !supplierData.mobile || !supplierData.nationalCode) {
                            showNotification('لطفاً تمامی فیلدهای اجباری ستاره‌دار (*) را پر کنید.', 'error');
                            return;
                          }
                          if (!/^09\d{9}$/.test(supplierData.mobile)) {
                            showNotification('شماره موبایل وارد شده نامعتبر است. فرمت صحیح: 09123456789', 'error');
                            return;
                          }
                          if (supplierData.nationalCode.length !== 10) {
                            showNotification('کد ملی باید دقیقاً ۱۰ رقم باشد.', 'error');
                            return;
                          }
                          setSupplierStep(2);
                        }}
                        className="w-full bg-slate-900 text-white font-medium py-3 px-4 rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 text-sm"
                      >
                        ادامه مسیر ثبت‌نام
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 2: Business Info */}
                  {supplierStep === 2 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام برند / نام تجاری *</label>
                          <input 
                            type="text" 
                            required
                            value={supplierData.brandName}
                            onChange={(e) => setSupplierData({...supplierData, brandName: e.target.value})}
                            placeholder="نام تجاری کسب‌وکار"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نوع فعالیت اصلی *</label>
                          <select 
                            value={supplierData.activityType}
                            onChange={(e) => setSupplierData({...supplierData, activityType: e.target.value})}
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          >
                            <option value="PRODUCER">تولیدکننده</option>
                            <option value="WHOLESALER">عمده‌فروش / بنکدار</option>
                            <option value="IMPORTER">واردکننده مستقیم</option>
                            <option value="OTHER">سایر</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">استان *</label>
                          <select 
                            value={supplierData.province}
                            onChange={(e) => setSupplierData({...supplierData, province: e.target.value, city: ''})}
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                          >
                            <option value="">انتخاب کنید</option>
                            {PROVINCES.map(p => (
                              <option key={p.name} value={p.name}>{p.name}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">شهر *</label>
                          <select 
                            value={supplierData.city}
                            onChange={(e) => setSupplierData({...supplierData, city: e.target.value})}
                            disabled={!supplierData.province}
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 disabled:opacity-50"
                          >
                            <option value="">انتخاب کنید</option>
                            {getCitiesForProvince(supplierData.province).map(c => (
                              <option key={c} value={c}>{c}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">کد پستی *</label>
                          <input 
                            type="text" 
                            required
                            value={supplierData.postalCode}
                            onChange={(e) => setSupplierData({...supplierData, postalCode: e.target.value})}
                            placeholder="کد پستی ۱۰ رقمی"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">نشانی دقیق دفتر مرکزی یا انبار *</label>
                        <textarea 
                          rows={2}
                          value={supplierData.address}
                          onChange={(e) => setSupplierData({...supplierData, address: e.target.value})}
                          placeholder="مثال: تهران، خیابان شریعتی، بن‌بست الوند، پلاک ۲، واحد ۴"
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">تلفن ثابت فروشگاه/شرکت *</label>
                          <input 
                            type="tel" 
                            required
                            value={supplierData.telephone}
                            onChange={(e) => setSupplierData({...supplierData, telephone: e.target.value})}
                            placeholder="مثال: 02188888888"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">آدرس وب‌سایت یا کانال فروش (اختیاری)</label>
                          <input 
                            type="url" 
                            value={supplierData.website}
                            onChange={(e) => setSupplierData({...supplierData, website: e.target.value})}
                            placeholder="https://mybrand.ir"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          if (!supplierData.brandName || !supplierData.province || !supplierData.city || !supplierData.address || !supplierData.postalCode || !supplierData.telephone) {
                            showNotification('لطفاً تمامی فیلدهای اجباری ستاره‌دار (*) را پر کنید.', 'error');
                            return;
                          }
                          setSupplierStep(3);
                        }}
                        className="w-full bg-slate-900 text-white font-medium py-3 px-4 rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 text-sm"
                      >
                        ادامه مسیر ثبت‌نام
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 3: Financial Details */}
                  {supplierStep === 3 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex gap-3 text-amber-900 text-xs">
                        <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block mb-1">دقت در وارد کردن اطلاعات شبا</span>
                          جهت تسویه حساب و واریز اتوماتیک سهم تامین‌کننده، حتماً شبا بانکی معتبر متعلق به نام صاحب کسب‌وکار را وارد نمایید.
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام و نام خانوادگی صاحب حساب *</label>
                        <input 
                          type="text" 
                          required
                          value={supplierData.accountHolderName}
                          onChange={(e) => setSupplierData({...supplierData, accountHolderName: e.target.value})}
                          placeholder="نام کامل ثبت شده در بانک"
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-1.5">
                          <label className="block text-xs font-semibold text-slate-700">شماره شبا (IBAN) *</label>
                          {supplierData.shaba.length >= 24 && (
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              formatAndValidateShaba(supplierData.shaba).isValid ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {formatAndValidateShaba(supplierData.shaba).isValid ? '✓ شبا معتبر است' : '✗ شبا نامعتبر است'}
                            </span>
                          )}
                        </div>
                        <div className="relative">
                          <input 
                            type="text" 
                            required
                            value={supplierData.shaba}
                            onChange={(e) => {
                              let val = e.target.value;
                              setSupplierData({...supplierData, shaba: val});
                            }}
                            maxLength={30}
                            placeholder="IR000000000000000000000000"
                            className={`w-full px-4 py-2.5 bg-slate-50 border rounded-xl text-sm focus:outline-none focus:ring-2 transition-colors text-left font-mono ${
                              supplierData.shaba.length >= 24 
                                ? formatAndValidateShaba(supplierData.shaba).isValid 
                                  ? 'border-emerald-300 focus:ring-emerald-500' 
                                  : 'border-rose-300 focus:ring-rose-500' 
                                : 'border-slate-200 focus:ring-indigo-500'
                            }`}
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">با یا بدون پیشوند IR و فاصله قابل قبول است.</p>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام بانک صادرکننده کارت/حساب *</label>
                        <input 
                          type="text" 
                          required
                          value={supplierData.bankName}
                          onChange={(e) => setSupplierData({...supplierData, bankName: e.target.value})}
                          placeholder="مثال: بانک ملی، ملت، سامان و ..."
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>

                      <button 
                        onClick={() => {
                          if (!supplierData.accountHolderName || !supplierData.shaba || !supplierData.bankName) {
                            showNotification('لطفاً تمامی فیلدهای اجباری ستاره‌دار (*) را پر کنید.', 'error');
                            return;
                          }
                          if (!formatAndValidateShaba(supplierData.shaba).isValid) {
                            showNotification('شماره شبا وارد شده نامعتبر است. فرمت صحیح: ۲۴ رقم عددی با یا بدون IR', 'error');
                            return;
                          }
                          setSupplierStep(4);
                        }}
                        className="w-full bg-slate-900 text-white font-medium py-3 px-4 rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 text-sm"
                      >
                        ادامه مسیر ثبت‌نام
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 4: Terms and Conditions */}
                  {supplierStep === 4 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                        <div className="flex items-center gap-2">
                          <FileText className="w-5 h-5 text-indigo-600" />
                          <h4 className="font-bold text-slate-900 text-sm">قوانین و ضوابط همکاری پلتفرم بازارگاه</h4>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed font-light">
                          عضویت و فعالیت در بازارگاه به عنوان تامین‌کننده مستلزم مطالعه دقیق، پذیرش بندهای حقوقی و تعهد به تامین کالای باکیفیت و اصل، همگام با قیمت‌گذاری منصفانه است.
                        </p>
                        <button 
                          onClick={() => {
                            setShowTermsModal(true);
                            setTermsReadProgress(true);
                          }}
                          className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                        >
                          <Info className="w-4 h-4" />
                          نمایش و مطالعه کامل متن قوانین همکاری
                        </button>
                      </div>

                      <div className="flex items-start gap-2.5">
                        <input 
                          type="checkbox" 
                          id="supplier-terms"
                          checked={supplierData.termsAccepted}
                          onChange={(e) => {
                            const isChecked = e.target.checked;
                            setSupplierData({
                              ...supplierData, 
                              termsAccepted: isChecked,
                              agreementVersion: isChecked ? '1.0' : '',
                              agreementAcceptedAt: isChecked ? new Date().toISOString() : ''
                            });
                          }}
                          className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300 w-4 h-4 mt-0.5"
                        />
                        <label htmlFor="supplier-terms" className="text-xs text-slate-700 leading-relaxed select-none cursor-pointer">
                          اینجانب ضمن مطالعه کامل شرایط و قوانین فعالیت تأمین‌کنندگان در پلتفرم بانک کالا، تمامی مفاد آن را پذیرفته و متعهد به رعایت آن هستم.
                        </label>
                      </div>

                      <button 
                        onClick={() => {
                          if (!supplierData.termsAccepted) {
                            showNotification('لطفاً ابتدا گزینه پذیرش قوانین را تایید نمایید.', 'error');
                            return;
                          }
                          setSupplierStep(5);
                        }}
                        className="w-full bg-indigo-600 text-white font-medium py-3 px-4 rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={!supplierData.termsAccepted}
                      >
                        ادامه به مرحله نهایی ساخت اکانت
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 5: Account Credentials Creation */}
                  {supplierStep === 5 && (
                    <div className="space-y-4 animate-fade-in">
                      {registerError && (
                        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex flex-col gap-1">
                          <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
                            <AlertCircle className="w-4 h-4" />
                            خطا در ثبت‌نام
                          </div>
                          <div className="text-xs text-rose-600 leading-relaxed">
                            {registerError}
                          </div>
                        </div>
                      )}
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام کاربری اختصاصی (Username) *</label>
                        <input 
                          type="text" 
                          required
                          value={supplierData.username}
                          onChange={(e) => setSupplierData({...supplierData, username: e.target.value})}
                          placeholder="مثال: parsa_trading"
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-left font-mono"
                          style={{ direction: 'ltr' }}
                        />
                        <p className="text-[10px] text-slate-400 mt-1">نام کاربری باید یکتا و به صورت حروف انگلیسی، اعداد یا کاراکتر زیرخط (_) باشد.</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">کلمه عبور (Password) *</label>
                          <input 
                            type="password" 
                            required
                            value={supplierData.password}
                            onChange={(e) => setSupplierData({...supplierData, password: e.target.value})}
                            placeholder="کلمه عبور مطمئن"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">تکرار کلمه عبور *</label>
                          <input 
                            type="password" 
                            required
                            value={supplierData.confirmPassword}
                            onChange={(e) => setSupplierData({...supplierData, confirmPassword: e.target.value})}
                            placeholder="مجدداً کلمه عبور را وارد کنید"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <button 
                        onClick={handleSupplierRegister}
                        disabled={loading}
                        className="w-full bg-indigo-600 text-white font-medium py-3 px-4 rounded-xl hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 text-sm shadow-md"
                      >
                        {loading ? (
                          <span className="flex items-center gap-2">
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            در حال ایجاد حساب کاربری...
                          </span>
                        ) : (
                          'اتمام ثبت‌نام و ورود مستقیم به داشبورد'
                        )}
                      </button>
                    </div>
                  )}

                </div>
              </div>
            )}


            {/* 4. STORE MANAGER MULTI-STEP FORM */}
            {view === 'store_manager_form' && (
              <div id="view-store-form" className="space-y-6 animate-fade-in">
                
                {/* Header & Back */}
                <div className="flex items-center justify-between">
                  <button 
                    onClick={() => {
                      if (storeStep > 1) {
                        setStoreStep(storeStep - 1);
                      } else {
                        setView('role_select');
                      }
                    }}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-medium transition-colors"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    {storeStep === 1 ? 'بازگشت به انتخاب نقش' : 'مرحله قبل'}
                  </button>
                  <span className="text-xs font-semibold text-slate-400">نقش: مدیر فروشگاه</span>
                </div>

                {/* Progress Indicators */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span className="font-semibold text-emerald-600">مرحله {storeStep} از ۴</span>
                    <span>
                      {storeStep === 1 && 'مشخصات فردی مدیر'}
                      {storeStep === 2 && 'اطلاعات فروشگاه'}
                      {storeStep === 3 && 'اتصال فنی فروشگاه (آینده)'}
                      {storeStep === 4 && 'اطلاعات ورود به اکانت'}
                    </span>
                  </div>
                  {/* Step bar */}
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex flex-row-reverse">
                    <div 
                      className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                      style={{ width: `${(storeStep / 4) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Form Step Contents */}
                <div className="space-y-4">
                  
                  {/* STEP 1: Personal */}
                  {storeStep === 1 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام مدیر فروشگاه *</label>
                          <input 
                            type="text" 
                            required
                            value={storeData.firstName}
                            onChange={(e) => setStoreData({...storeData, firstName: e.target.value})}
                            placeholder="مثال: سهراب"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام خانوادگی *</label>
                          <input 
                            type="text" 
                            required
                            value={storeData.lastName}
                            onChange={(e) => setStoreData({...storeData, lastName: e.target.value})}
                            placeholder="مثال: سپهری"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">شماره موبایل *</label>
                          <input 
                            type="tel" 
                            required
                            value={storeData.mobile}
                            onChange={(e) => setStoreData({...storeData, mobile: e.target.value})}
                            placeholder="09121111111"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left font-mono"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">آدرس ایمیل *</label>
                          <input 
                            type="email" 
                            required
                            value={storeData.email}
                            onChange={(e) => setStoreData({...storeData, email: e.target.value})}
                            placeholder="example@gmail.com"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left font-mono"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          if (!storeData.firstName || !storeData.lastName || !storeData.mobile || !storeData.email) {
                            showNotification('لطفاً تمامی فیلدهای الزامی را تکمیل کنید.', 'error');
                            return;
                          }
                          if (!/^09\d{9}$/.test(storeData.mobile)) {
                            showNotification('شماره موبایل معتبر نیست.', 'error');
                            return;
                          }
                          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(storeData.email)) {
                            showNotification('آدرس ایمیل وارد شده معتبر نیست.', 'error');
                            return;
                          }
                          setStoreStep(2);
                        }}
                        className="w-full bg-slate-900 text-white font-medium py-3 px-4 rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 text-sm"
                      >
                        ادامه ثبت‌نام فروشگاه
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 2: Store details */}
                  {storeStep === 2 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام فروشگاه *</label>
                          <input 
                            type="text" 
                            required
                            value={storeData.storeName}
                            onChange={(e) => setStoreData({...storeData, storeName: e.target.value})}
                            placeholder="نام تجاری فروشگاه آنلاین"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">آدرس اینترنتی وب‌سایت فروشگاه</label>
                          <input 
                            type="url" 
                            value={storeData.storeUrl}
                            onChange={(e) => setStoreData({...storeData, storeUrl: e.target.value})}
                            placeholder="https://mystore.ir"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left font-mono"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="col-span-1">
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">پلتفرم مدیریت فروشگاه *</label>
                          <select 
                            value={storeData.platformType}
                            onChange={(e) => setStoreData({...storeData, platformType: e.target.value})}
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          >
                            <option value="WOOCOMMERCE">ووکامرس (WooCommerce)</option>
                            <option value="SHOPIFY">شاپیفای (Shopify)</option>
                            <option value="OTHER">سایر سیستم‌ها</option>
                          </select>
                        </div>
                        <div className="col-span-1">
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">حوزه فعالیت اصلی *</label>
                          <input 
                            type="text" 
                            required
                            value={storeData.fieldOfActivity}
                            onChange={(e) => setStoreData({...storeData, fieldOfActivity: e.target.value})}
                            placeholder="مثال: آرایشی، پوشاک، دیجیتال"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div className="col-span-1">
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">تعداد محصولات فعلی *</label>
                          <input 
                            type="number" 
                            required
                            value={storeData.productCount}
                            onChange={(e) => setStoreData({...storeData, productCount: e.target.value})}
                            placeholder="عدد وارد کنید"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          if (!storeData.storeName || !storeData.fieldOfActivity || !storeData.productCount) {
                            showNotification('لطفاً فیلدهای اجباری را تکمیل کنید.', 'error');
                            return;
                          }
                          setStoreStep(3);
                        }}
                        className="w-full bg-slate-900 text-white font-medium py-3 px-4 rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 text-sm"
                      >
                        ادامه ثبت‌نام فروشگاه
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 3: Connect Account (Integration) */}
                  {storeStep === 3 && (
                    <div className="space-y-4 animate-fade-in">
                      <div className="p-5 border border-dashed border-slate-300 rounded-2xl bg-slate-50 flex flex-col items-center text-center space-y-4">
                        <div className="w-16 h-16 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 animate-pulse">
                          <Database className="w-8 h-8" />
                        </div>
                        <div className="space-y-1">
                          <h4 className="font-bold text-slate-900 text-sm">اتصال هوشمند فنی به بازارگاه (به زودی)</h4>
                          <p className="text-xs text-slate-500 max-w-md leading-relaxed font-light">
                            در آینده نزدیک، شما قادر خواهید بود با وارد کردن کلیدهای API فروشگاه (WooCommerce Consumer Key یا Shopify Access Token)، فرآیند همگام‌سازی اتوماتیک قیمت‌ها، موجودی انبار و پردازش اتوماتیک سفارشات را فعال کنید.
                          </p>
                        </div>
                        <div className="flex gap-4 items-center">
                          <span className="text-xs text-slate-400 bg-white border px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></span>
                            آماده‌سازی فنی در جریان
                          </span>
                        </div>
                      </div>

                      <button 
                        onClick={() => setStoreStep(4)}
                        className="w-full bg-emerald-600 text-white font-medium py-3 px-4 rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 text-sm shadow-md"
                      >
                        عبور از این مرحله و ساخت اکانت
                        <ArrowLeft className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 4: Account Credentials */}
                  {storeStep === 4 && (
                    <div className="space-y-4 animate-fade-in">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1.5">نام کاربری اختصاصی (Username) *</label>
                        <input 
                          type="text" 
                          required
                          value={storeData.username}
                          onChange={(e) => setStoreData({...storeData, username: e.target.value})}
                          placeholder="مثال: store_manager_sam"
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left font-mono"
                          style={{ direction: 'ltr' }}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">کلمه عبور *</label>
                          <input 
                            type="password" 
                            required
                            value={storeData.password}
                            onChange={(e) => setStoreData({...storeData, password: e.target.value})}
                            placeholder="رمز عبور شما"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1.5">تکرار کلمه عبور *</label>
                          <input 
                            type="password" 
                            required
                            value={storeData.confirmPassword}
                            onChange={(e) => setStoreData({...storeData, confirmPassword: e.target.value})}
                            placeholder="مجدداً کلمه عبور"
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 text-left"
                            style={{ direction: 'ltr' }}
                          />
                        </div>
                      </div>

                      <button 
                        onClick={handleStoreManagerRegister}
                        disabled={loading}
                        className="w-full bg-emerald-600 text-white font-medium py-3 px-4 rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 text-sm shadow-md"
                      >
                        {loading ? (
                          <span className="flex items-center gap-2">
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            در حال ایجاد حساب کاربری...
                          </span>
                        ) : (
                          'اتمام ثبت‌نام و ورود مستقیم به داشبورد'
                        )}
                      </button>
                    </div>
                  )}

                </div>
              </div>
            )}


            
        </div>
        </div>
      </main>
      {/* Footer */}
      <footer className="text-center py-4 text-xs text-slate-400 bg-slate-50 border-t border-slate-100">
        سامانه بازارگاه تامین و توزیع • طراحی RTL و بهینه‌سازی واکنش‌گرا (Mobile-First) • کلیه حقوق امنیتی محفوظ است.
      </footer>

      {/* RULES AND TERMS MODAL */}
      {showTermsModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-scale-in max-h-[85vh] flex flex-col">
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
              <h3 className="font-bold text-lg">شرایط و قوانین فعالیت تأمین‌کنندگان در پلتفرم بانک کالا</h3>
              <button 
                onClick={() => setShowTermsModal(false)}
                className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
              >
                ✕
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-700 leading-relaxed font-light text-right">
              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">مقدمه</h4>
                <p>
                  عضویت در پلتفرم <strong>بانک کالا</strong> و ثبت هرگونه کالا در سامانه، به منزله مطالعه دقیق، آگاهی کامل و پذیرش تمامی شرایط و قوانین زیر است. تأیید این شرایط از طریق انتخاب گزینه «می‌پذیرم» در زمان ثبت‌نام، به منزله موافقت تأمین‌کننده با مفاد این قوانین خواهد بود.
                  بانک کالا یک بستر هوشمند برای ایجاد ارتباط میان تأمین‌کنندگان و شبکه فروشگاه‌های همکار است و نقش آن تسهیل فرآیند عرضه، فروش، مدیریت سفارش و تسویه‌حساب می‌باشد.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">۱. نحوه فعالیت و قیمت‌گذاری</h4>
                <ul className="list-disc pr-5 space-y-1">
                  <li>تأمین‌کننده موظف است مشخصات کامل، موجودی و <strong>قیمت پایه موردنظر</strong> خود را برای هر کالا در سامانه ثبت نماید.</li>
                  <li>بانک کالا کالاهای ثبت‌شده را با احتساب حاشیه سود مربوط به هزینه‌های زیرساخت، خدمات سامانه و شبکه فروشگاه‌های همکار در کانال‌های فروش عرضه می‌کند.</li>
                  <li>مبلغ قابل پرداخت به تأمین‌کننده همان <strong>قیمت پایه ثبت‌شده توسط وی</strong> خواهد بود و پس از نهایی شدن فروش، پایان مهلت بررسی سفارش و کسر سهم پلتفرم، مطابق برنامه مالی سامانه به کیف پول یا حساب بانکی معرفی‌شده واریز می‌شود.</li>
                  <li>تأمین‌کننده مسئول به‌روزرسانی قیمت پایه و موجودی کالاهای خود است.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">۲. مدیریت سفارش و ارسال کالا</h4>
                <ul className="list-disc pr-5 space-y-1">
                  <li>پس از ثبت سفارش، تأمین‌کننده متعهد است حداکثر ظرف <strong>۲۴ ساعت کاری</strong> وضعیت سفارش را بررسی، تأیید و کالا را برای ارسال آماده نماید.</li>
                  <li>ارسال کالا ترجیحاً از طریق سرویس‌های حمل‌ونقل متصل به بانک کالا انجام می‌شود.</li>
                  <li>در صورتی که ارسال توسط تأمین‌کننده انجام شود، ثبت کد رهگیری معتبر در سامانه الزامی است.</li>
                  <li>تأخیرهای مکرر در تأیید سفارش، ارسال کالا یا لغو سفارش بدون دلیل موجه، ممکن است منجر به محدود شدن یا تعلیق دسترسی تأمین‌کننده به خدمات سامانه شود.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">۳. کیفیت کالا و رسیدگی به سفارش</h4>
                <ul className="list-disc pr-5 space-y-1">
                  <li>تأمین‌کننده اصالت، سلامت فیزیکی، کیفیت و مطابقت کامل کالای ارسالی با اطلاعات ثبت‌شده در سامانه را تضمین می‌کند.</li>
                  <li>مشتری نهایی تا <strong>۴۸ ساعت پس از تحویل کالا</strong> فرصت دارد مغایرت، نقص یا آسیب‌دیدگی کالا را گزارش نماید.</li>
                  <li>در صورت تأیید ایراد، تأمین‌کننده متعهد به همکاری در فرآیند تعویض، مرجوعی یا جبران خسارت مطابق سیاست‌های بانک کالا خواهد بود.</li>
                  <li>تا پایان مهلت بررسی سفارش و تعیین تکلیف احتمالی مرجوعی، تسویه‌حساب آن سفارش ممکن است به تعویق بیفتد.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">۴. مسئولیت‌ها</h4>
                <ul className="list-disc pr-5 space-y-1">
                  <li>بانک کالا صرفاً ارائه‌دهنده بستر نرم‌افزاری، مدیریت شبکه فروش، تسهیل فرآیند سفارش و امور مالی میان طرفین است.</li>
                  <li>مسئولیت قانونی کیفیت، اصالت، موجودی، مجوزهای لازم، اطلاعات درج‌شده و قابلیت فروش کالا بر عهده تأمین‌کننده است.</li>
                  <li>ثبت کالاهای غیرقانونی، قاچاق، تقلبی، ناقض حقوق مالکیت فکری یا مغایر با قوانین جمهوری اسلامی ایران ممنوع بوده و مسئولیت کامل آن بر عهده تأمین‌کننده خواهد بود.</li>
                  <li>در صورت وارد شدن هرگونه خسارت به مشتری، فروشگاه همکار یا بانک کالا ناشی از اطلاعات نادرست، کیفیت نامناسب یا عدم انجام تعهدات، مسئولیت جبران خسارت بر عهده تأمین‌کننده خواهد بود.</li>
                  <li>تأمین‌کننده موظف است در صورت اتمام موجودی، وضعیت کالا را بلافاصله در سامانه به‌روزرسانی نماید.</li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">۵. محرمانگی اطلاعات</h4>
                <p>تأمین‌کننده متعهد است اطلاعات مربوط به سفارش‌ها، مشتریان، فروشگاه‌های همکار، قیمت‌ها، گزارش‌ها و سایر اطلاعات تجاری بانک کالا را محرمانه تلقی کرده و از استفاده از این اطلاعات برای ارتباط مستقیم با مشتریان یا فروشگاه‌های همکار خارج از بستر بانک کالا خودداری نماید.</p>
              </div>

              <div>
                <h4 className="font-bold text-slate-900 text-sm mb-2">۶. اصلاح قوانین</h4>
                <p>بانک کالا در صورت نیاز، حق اصلاح یا به‌روزرسانی این شرایط و قوانین را مطابق تغییرات خدمات یا الزامات قانونی برای خود محفوظ می‌داند. ادامه استفاده از سامانه پس از اعمال تغییرات، به منزله پذیرش نسخه جدید قوانین خواهد بود.</p>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button 
                onClick={() => {
                  setSupplierData({
                    ...supplierData, 
                    termsAccepted: true,
                    agreementVersion: '1.0',
                    agreementAcceptedAt: new Date().toISOString()
                  });
                  setShowTermsModal(false);
                  showNotification('قوانین با موفقیت تایید و امضا شد.', 'success');
                }}
                className="bg-slate-900 text-white font-bold px-6 py-2.5 rounded-xl hover:bg-slate-800 transition-all text-sm"
              >
                مطالعه کردم و قوانین را می‌پذیرم
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

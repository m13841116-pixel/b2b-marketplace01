import React, { useState, useEffect } from 'react';
import { 
  Package, 
  ShoppingCart, 
  Wallet, 
  LayoutDashboard, 
  LogOut,
  Plus,
  Search,
  CheckCircle,
  Clock,
  TrendingUp,
  AlertCircle,
  X,
  PlusCircle,
  MessageSquare,
  User,
  Settings
} from 'lucide-react';
import { SupplierAddProduct } from './SupplierAddProduct';
import { SupplierTickets } from './SupplierTickets';
import { SupplierProfile } from './SupplierProfile';

export function SupplierDashboard({ user, onLogout, showNotification }: any) {
  const [activeTab, setActiveTab] = useState('overview');
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [walletInfo, setWalletInfo] = useState<{ wallet: any, transactions: any[] }>({ wallet: null, transactions: [] });
  const [loading, setLoading] = useState(true);
  const [productToEdit, setProductToEdit] = useState<any>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      const [prodRes, ordRes, walRes] = await Promise.all([
        fetch('/api/supplier/products', { headers }),
        fetch('/api/supplier/orders', { headers }),
        fetch('/api/supplier/wallet', { headers })
      ]);

      if (prodRes.ok) setProducts(await prodRes.json());
      if (ordRes.ok) setOrders(await ordRes.json());
      if (walRes.ok) setWalletInfo(await walRes.json());
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const updateOrderStatus = async (itemId: number, newStatus: string) => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/supplier/orders/${itemId}`, {
        method: 'PATCH',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (res.ok) {
        setOrders(orders.map(o => o.id === itemId ? { ...o, status: newStatus } : o));
        showNotification('وضعیت سفارش بروز شد.', 'success');
      }
    } catch (err) {
      showNotification('خطا در بروزرسانی سفارش', 'error');
    }
  };

  const navItems = [
    { id: 'overview', label: 'پیشخوان', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'products', label: 'محصولات من', icon: <Package className="w-5 h-5" /> },
    { id: 'add-product', label: 'افزودن محصول', icon: <PlusCircle className="w-5 h-5" /> },
    { id: 'orders', label: 'سفارشات', icon: <ShoppingCart className="w-5 h-5" /> },
    { id: 'wallet', label: 'کیف پول و تسویه', icon: <Wallet className="w-5 h-5" /> },
    { id: 'tickets', label: 'تیکت‌ها', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'profile', label: 'پروفایل من', icon: <User className="w-5 h-5" /> },
  ];

  return (
    <div className="flex h-screen bg-slate-50 w-full" dir="rtl">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col h-full shadow-xl z-10">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Package className="text-indigo-400" />
            پنل تامین‌کننده
          </h2>
          <p className="text-slate-400 text-xs mt-2 truncate">
            {user?.firstName} {user?.lastName} ({user?.brandName})
          </p>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                activeTab === item.id 
                  ? 'bg-indigo-600 text-white' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose-400 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            خروج از حساب
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="bg-white px-8 py-5 flex items-center justify-between border-b border-slate-200 shadow-sm z-0">
          <h1 className="text-2xl font-bold text-slate-800">
            {navItems.find(i => i.id === activeTab)?.label}
          </h1>
          <div className="flex items-center gap-4">
            <div className="bg-slate-100 text-slate-600 text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              حساب فعال
            </div>
          </div>
        </header>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-auto p-8 relative">
          
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
            </div>
          ) : (
            <>
              {/* OVERVIEW TAB */}
              {activeTab === 'overview' && (
                <div className="space-y-8 animate-fade-in">
                  
                  {/* Welcome Banner */}
                  <div className="bg-gradient-to-l from-indigo-900 to-indigo-700 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
                    <div className="relative z-10">
                      <h2 className="text-3xl font-bold mb-2">سلام، {user?.firstName || 'همکار'} عزیز! 👋</h2>
                      <p className="text-indigo-100 max-w-lg mb-6">به پنل تامین‌کنندگان خوش آمدید. در اینجا می‌توانید محصولات خود را مدیریت کنید و وضعیت سفارشات و تسویه‌حساب‌ها را پیگیری نمایید.</p>
                      <button 
                        onClick={() => setActiveTab('add-product')}
                        className="bg-white text-indigo-900 px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-colors shadow-sm"
                      >
                        افزودن محصول جدید
                      </button>
                    </div>
                    {/* Decorative Elements */}
                    <div className="absolute left-0 top-0 w-64 h-full opacity-20 pointer-events-none">
                      <div className="absolute right-10 top-10 w-32 h-32 bg-white rounded-full mix-blend-overlay filter blur-3xl"></div>
                      <div className="absolute left-10 bottom-10 w-40 h-40 bg-indigo-400 rounded-full mix-blend-overlay filter blur-3xl"></div>
                    </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-5 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setActiveTab('products')}>
                      <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                        <Package className="w-8 h-8" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium mb-1">تعداد محصولات</p>
                        <h3 className="text-3xl font-black text-slate-900">{products.length}</h3>
                      </div>
                    </div>
                    
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-5 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setActiveTab('orders')}>
                      <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <ShoppingCart className="w-8 h-8" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium mb-1">سفارشات در جریان</p>
                        <h3 className="text-3xl font-black text-slate-900">
                          {orders.filter(o => o.status !== 'DELIVERED').length}
                        </h3>
                      </div>
                    </div>
                    
                    <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-5 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setActiveTab('wallet')}>
                      <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
                        <Wallet className="w-8 h-8" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium mb-1">موجودی کیف پول (تومان)</p>
                        <h3 className="text-2xl font-black text-slate-900">
                          {(walletInfo.wallet?.balance || 0).toLocaleString()}
                        </h3>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Recent Orders */}
                    <div className="lg:col-span-2 bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                      <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-slate-800">آخرین سفارشات</h3>
                        <button onClick={() => setActiveTab('orders')} className="text-indigo-600 text-sm font-semibold hover:text-indigo-700">مشاهده همه</button>
                      </div>
                      
                      {orders.length > 0 ? (
                        <div className="space-y-3">
                          {orders.slice(0, 4).map(order => (
                            <div key={order.id} className="flex items-center justify-between p-4 bg-slate-50 hover:bg-slate-100 transition-colors rounded-2xl border border-slate-100">
                              <div className="flex items-center gap-4">
                                <div className={`p-3 rounded-xl ${
                                  order.status === 'PENDING' ? 'bg-amber-100 text-amber-600' : 
                                  order.status === 'PROCESSING' ? 'bg-blue-100 text-blue-600' :
                                  'bg-emerald-100 text-emerald-600'
                                }`}>
                                  <Clock className="w-5 h-5" />
                                </div>
                                <div>
                                  <p className="font-bold text-slate-800">سفارش #{order.id}</p>
                                  <p className="text-xs text-slate-500 mt-1">{order.product?.name}</p>
                                </div>
                              </div>
                              <div className="text-left flex flex-col items-end">
                                <span className={`px-3 py-1.5 rounded-full text-xs font-bold inline-block mb-1 ${
                                  order.status === 'PENDING' ? 'bg-amber-100 text-amber-700' : 
                                  order.status === 'PROCESSING' ? 'bg-blue-100 text-blue-700' :
                                  'bg-emerald-100 text-emerald-700'
                                }`}>
                                  {order.status === 'PENDING' ? 'در انتظار بررسی' : order.status === 'PROCESSING' ? 'در حال پردازش' : 'ارسال شده'}
                                </span>
                                <p className="text-xs text-slate-500 font-mono mt-1">
                                  {new Date(order.createdAt).toLocaleDateString('fa-IR')}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-10">
                          <Package className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                          <p className="text-slate-500 font-medium">سفارشی ثبت نشده است</p>
                        </div>
                      )}
                    </div>

                    {/* Quick Actions */}
                    <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-sm flex flex-col justify-between relative overflow-hidden">
                      <div className="relative z-10">
                        <h3 className="text-lg font-bold mb-6 text-white">دسترسی سریع</h3>
                        <div className="space-y-3">
                          <button onClick={() => setActiveTab('add-product')} className="w-full flex items-center justify-between p-4 bg-slate-800/50 hover:bg-slate-800 rounded-2xl transition-colors border border-slate-700/50">
                            <span className="font-medium">ثبت محصول جدید</span>
                            <PlusCircle className="w-5 h-5 text-indigo-400" />
                          </button>
                          <button onClick={() => setActiveTab('tickets')} className="w-full flex items-center justify-between p-4 bg-slate-800/50 hover:bg-slate-800 rounded-2xl transition-colors border border-slate-700/50">
                            <span className="font-medium">پشتیبانی و تیکت‌ها</span>
                            <MessageSquare className="w-5 h-5 text-indigo-400" />
                          </button>
                          <button onClick={() => setActiveTab('profile')} className="w-full flex items-center justify-between p-4 bg-slate-800/50 hover:bg-slate-800 rounded-2xl transition-colors border border-slate-700/50">
                            <span className="font-medium">ویرایش پروفایل</span>
                            <User className="w-5 h-5 text-indigo-400" />
                          </button>
                        </div>
                      </div>
                      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-indigo-500/20 rounded-full mix-blend-overlay filter blur-3xl"></div>
                    </div>
                  </div>
                </div>
              )}

              {/* PRODUCTS TAB */}
              {activeTab === 'products' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
                    <div className="relative w-64">
                      <input 
                        type="text"
                        placeholder="جستجوی محصول..."
                        className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    </div>
                    <button 
                      onClick={() => setActiveTab('add-product')}
                      className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-colors flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      افزودن محصول جدید
                    </button>
                  </div>

                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                    {products.length > 0 ? (
                      <table className="w-full text-right text-sm">
                        <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                          <tr>
                            <th className="px-6 py-4">شناسه</th>
                            <th className="px-6 py-4">نام محصول</th>
                            <th className="px-6 py-4">برند</th>
                            <th className="px-6 py-4">موجودی</th>
                            <th className="px-6 py-4">قیمت پایه (تومان)</th>
                            <th className="px-6 py-4">وضعیت</th>
                            <th className="px-6 py-4">عملیات</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {products.map(product => (
                            <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                              <td className="px-6 py-4 font-mono text-slate-500">#{product.id}</td>
                              <td className="px-6 py-4 font-semibold text-slate-800">{product.name}</td>
                              <td className="px-6 py-4 text-slate-600">{product.brand || '-'}</td>
                              <td className="px-6 py-4 text-slate-600">{product.variants?.[0]?.stock || 0}</td>
                              <td className="px-6 py-4 font-bold text-slate-800">
                                {product.supplierBasePrice.toLocaleString()}
                              </td>
                              <td className="px-6 py-4">
                                <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                                  product.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-700'
                                }`}>
                                  {product.status === 'ACTIVE' ? 'فعال' : 'غیرفعال'}
                                </span>
                              </td>
                              <td className="px-6 py-4">
                                <button
                                  onClick={() => {
                                    setProductToEdit(product);
                                    setActiveTab('edit-product');
                                  }}
                                  className="text-indigo-600 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
                                >
                                  ویرایش
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-16 text-slate-500">
                        <Package className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                        <p className="text-lg font-medium text-slate-700 mb-1">محصولی یافت نشد</p>
                        <p className="text-sm">شما هنوز محصولی در فروشگاه خود ثبت نکرده‌اید.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ORDERS TAB */}
              {activeTab === 'orders' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                    {orders.length > 0 ? (
                      <table className="w-full text-right text-sm">
                        <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                          <tr>
                            <th className="px-6 py-4">سفارش</th>
                            <th className="px-6 py-4">محصول</th>
                            <th className="px-6 py-4">وضعیت</th>
                            <th className="px-6 py-4">کد رهگیری</th>
                            <th className="px-6 py-4">عملیات</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {orders.map(order => (
                            <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                              <td className="px-6 py-4 font-mono font-medium text-indigo-600">#{order.id}</td>
                              <td className="px-6 py-4 text-slate-800 font-medium">{order.product?.name}</td>
                              <td className="px-6 py-4">
                                <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                                  order.status === 'PENDING' ? 'bg-amber-100 text-amber-700' :
                                  order.status === 'PROCESSING' ? 'bg-blue-100 text-blue-700' :
                                  order.status === 'SHIPPED' ? 'bg-purple-100 text-purple-700' :
                                  'bg-emerald-100 text-emerald-700'
                                }`}>
                                  {order.status === 'PENDING' ? 'در انتظار بررسی' :
                                   order.status === 'PROCESSING' ? 'در حال پردازش' :
                                   order.status === 'SHIPPED' ? 'ارسال شده' : 'تحویل شده'}
                                </span>
                              </td>
                              <td className="px-6 py-4 font-mono text-slate-600 text-xs">
                                {order.trackingCode || '-'}
                              </td>
                              <td className="px-6 py-4">
                                {order.status === 'PENDING' && (
                                  <button 
                                    onClick={() => updateOrderStatus(order.id, 'PROCESSING')}
                                    className="text-xs bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                  >
                                    تایید و پردازش
                                  </button>
                                )}
                                {order.status === 'PROCESSING' && (
                                  <button 
                                    onClick={() => updateOrderStatus(order.id, 'SHIPPED')}
                                    className="text-xs bg-purple-50 text-purple-600 hover:bg-purple-100 px-3 py-1.5 rounded-lg font-medium transition-colors"
                                  >
                                    ثبت ارسال
                                  </button>
                                )}
                                {(order.status === 'SHIPPED' || order.status === 'DELIVERED') && (
                                  <span className="text-xs text-slate-400">بدون اقدام</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="text-center py-16 text-slate-500">
                        <ShoppingCart className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                        <p className="text-lg font-medium text-slate-700 mb-1">سفارشی ندارید</p>
                        <p className="text-sm">هنوز سفارشی برای محصولات شما ثبت نشده است.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* WALLET TAB */}
              {activeTab === 'wallet' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
                    <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-500 rounded-full blur-3xl opacity-30"></div>
                    <div className="absolute top-10 right-10 w-32 h-32 bg-purple-500 rounded-full blur-3xl opacity-20"></div>
                    
                    <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                      <div>
                        <p className="text-indigo-200 font-medium mb-1">موجودی قابل تسویه (تومان)</p>
                        <h2 className="text-4xl md:text-5xl font-bold tracking-tight">
                          {(walletInfo.wallet?.balance || 0).toLocaleString()}
                        </h2>
                        <div className="flex items-center gap-2 mt-4 text-sm text-indigo-200">
                          <CheckCircle className="w-4 h-4 text-emerald-400" />
                          شماره شبا ثبت شده: <span className="font-mono text-white text-xs">{user?.shaba}</span>
                        </div>
                      </div>
                      <button className="bg-white text-indigo-900 px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-indigo-50 transition-colors">
                        درخواست تسویه حساب
                      </button>
                    </div>
                  </div>

                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100">
                    <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                      <h3 className="font-bold text-slate-800 text-lg">تراکنش‌های اخیر</h3>
                    </div>
                    {walletInfo.transactions.length > 0 ? (
                      <div className="divide-y divide-slate-100">
                        {walletInfo.transactions.map((tx: any) => (
                          <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div className="flex items-center gap-4">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                tx.type === 'CREDIT' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'
                              }`}>
                                {tx.type === 'CREDIT' ? <TrendingUp className="w-5 h-5" /> : <TrendingUp className="w-5 h-5 transform rotate-180" />}
                              </div>
                              <div>
                                <p className="font-bold text-slate-800 text-sm">
                                  {tx.type === 'CREDIT' ? 'فروش محصول' : 'تسویه حساب'}
                                </p>
                                <p className="text-xs text-slate-500 mt-1 font-mono">
                                  {new Date(tx.createdAt).toLocaleDateString('fa-IR')}
                                </p>
                              </div>
                            </div>
                            <span className={`font-bold ${tx.type === 'CREDIT' ? 'text-emerald-600' : 'text-rose-600'}`}>
                              {tx.type === 'CREDIT' ? '+' : '-'}{tx.amount.toLocaleString()} تومان
                            </span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-8 text-center text-slate-500">
                        <Wallet className="w-12 h-12 mx-auto text-slate-300 mb-3" />
                        <p>هیچ تراکنشی یافت نشد.</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
              {/* ADD PRODUCT TAB */}
              {activeTab === 'add-product' && (
                <SupplierAddProduct 
                  onSuccess={() => {
                    fetchData();
                    setActiveTab('products');
                  }} 
                  onCancel={() => setActiveTab('products')} 
                  showNotification={showNotification} 
                />
              )}

              {/* EDIT PRODUCT TAB */}
              {activeTab === 'edit-product' && productToEdit && (
                <SupplierAddProduct 
                  initialData={productToEdit}
                  onSuccess={() => {
                    fetchData();
                    setActiveTab('products');
                    setProductToEdit(null);
                  }} 
                  onCancel={() => {
                    setActiveTab('products');
                    setProductToEdit(null);
                  }} 
                  showNotification={showNotification} 
                />
              )}

              {/* TICKETS TAB */}
              {activeTab === 'tickets' && (
                <SupplierTickets showNotification={showNotification} />
              )}

              {/* PROFILE TAB */}
              {activeTab === 'profile' && (
                <SupplierProfile user={user} showNotification={showNotification} />
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

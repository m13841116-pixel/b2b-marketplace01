import React, { useState, useEffect } from 'react';
import { MessageSquare, Plus, X, Send } from 'lucide-react';

export function SupplierTickets({ showNotification }: any) {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewTicket, setShowNewTicket] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New ticket state
  const [subject, setSubject] = useState('');
  const [department, setDepartment] = useState('پشتیبانی فنی');
  const [priority, setPriority] = useState('عادی');
  const [message, setMessage] = useState('');

  // Reply state
  const [reply, setReply] = useState('');

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/supplier/tickets', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setTickets(await res.json());
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !message) {
      showNotification('لطفاً موضوع و متن پیام را وارد کنید', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/supplier/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ subject, department, priority, message })
      });

      if (res.ok) {
        showNotification('تیکت با موفقیت ایجاد شد', 'success');
        setShowNewTicket(false);
        setSubject('');
        setMessage('');
        fetchTickets();
      } else {
        showNotification('خطا در ایجاد تیکت', 'error');
      }
    } catch (err) {
      showNotification('خطا در ارتباط با سرور', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reply || !selectedTicket) return;

    setIsSubmitting(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/supplier/tickets/${selectedTicket.id}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ message: reply })
      });

      if (res.ok) {
        setReply('');
        // Refresh selected ticket by refetching all and updating selected
        const updatedRes = await fetch('/api/supplier/tickets', {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (updatedRes.ok) {
          const updatedTickets = await updatedRes.json();
          setTickets(updatedTickets);
          const updatedSelected = updatedTickets.find((t: any) => t.id === selectedTicket.id);
          setSelectedTicket(updatedSelected);
        }
      } else {
        showNotification('خطا در ارسال پیام', 'error');
      }
    } catch (err) {
      showNotification('خطا در ارتباط با سرور', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (selectedTicket) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 flex flex-col h-[calc(100vh-8rem)]">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-800 text-lg">{selectedTicket.subject}</h3>
            <div className="flex gap-4 mt-2 text-sm text-slate-500">
              <span>بخش: {selectedTicket.department}</span>
              <span>وضعیت: {selectedTicket.status === 'OPEN' ? 'باز' : 'بسته'}</span>
            </div>
          </div>
          <button
            onClick={() => setSelectedTicket(null)}
            className="text-slate-400 hover:text-slate-600 bg-slate-50 hover:bg-slate-100 p-2 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50">
          {selectedTicket.messages.map((msg: any) => (
            <div key={msg.id} className={`flex ${msg.userId === selectedTicket.userId ? 'justify-start' : 'justify-end'}`}>
              <div className={`max-w-[80%] rounded-2xl p-4 ${msg.userId === selectedTicket.userId ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'}`}>
                <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                <span className={`text-[10px] mt-2 block ${msg.userId === selectedTicket.userId ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {new Date(msg.createdAt).toLocaleDateString('fa-IR')} - {new Date(msg.createdAt).toLocaleTimeString('fa-IR')}
                </span>
              </div>
            </div>
          ))}
        </div>

        {selectedTicket.status === 'OPEN' && (
          <div className="p-4 bg-white border-t border-slate-100">
            <form onSubmit={handleReply} className="flex gap-2">
              <input
                type="text"
                value={reply}
                onChange={e => setReply(e.target.value)}
                placeholder="پاسخ خود را بنویسید..."
                className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              />
              <button
                type="submit"
                disabled={isSubmitting || !reply}
                className="bg-indigo-600 text-white px-6 py-3 rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center"
              >
                <Send className="w-5 h-5 rtl:-scale-x-100" />
              </button>
            </form>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
        <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-indigo-600" />
          تیکت‌های پشتیبانی
        </h2>
        <button
          onClick={() => setShowNewTicket(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          تیکت جدید
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        {loading ? (
          <div className="p-12 flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
          </div>
        ) : tickets.length > 0 ? (
          <div className="divide-y divide-slate-100">
            {tickets.map(ticket => (
              <div 
                key={ticket.id} 
                onClick={() => setSelectedTicket(ticket)}
                className="p-4 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between"
              >
                <div>
                  <h4 className="font-bold text-slate-800 text-sm mb-1">{ticket.subject}</h4>
                  <div className="flex gap-4 text-xs text-slate-500">
                    <span>شماره: #{ticket.id}</span>
                    <span>بخش: {ticket.department}</span>
                    <span>{new Date(ticket.createdAt).toLocaleDateString('fa-IR')}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                    ticket.status === 'OPEN' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-700'
                  }`}>
                    {ticket.status === 'OPEN' ? 'باز' : 'بسته'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center">
            <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 font-medium">هیچ تیکتی یافت نشد</p>
          </div>
        )}
      </div>

      {showNewTicket && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl animate-fade-in">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-lg text-slate-800">ایجاد تیکت جدید</h3>
              <button 
                onClick={() => setShowNewTicket(false)}
                className="text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleCreateTicket} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">موضوع</label>
                <input 
                  type="text" 
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">بخش</label>
                  <select 
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option>پشتیبانی فنی</option>
                    <option>امور مالی</option>
                    <option>پیشنهادات و انتقادات</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">اولویت</label>
                  <select 
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option>عادی</option>
                    <option>مهم</option>
                    <option>فوری</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5">متن پیام</label>
                <textarea 
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                ></textarea>
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setShowNewTicket(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-700 rounded-xl font-medium hover:bg-slate-200 transition-colors"
                >
                  انصراف
                </button>
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? 'در حال ارسال...' : 'ارسال تیکت'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

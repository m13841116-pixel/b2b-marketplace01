import React, { useState, useEffect } from 'react';
import { 
  Store, ShoppingCart, Wallet, LayoutDashboard, LogOut,
  Search, CheckCircle, Clock, TrendingUp, AlertCircle, X,
  FileText, Settings, Plus, RefreshCw, Layers
} from 'lucide-react';

export default function StoreManagerDashboard({ user, onLogout }: any) {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<any>(null);
  const [marketplaceProducts, setMarketplaceProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({});
  const [loading, setLoading] = useState(true);

  // Settlements selection
  const [selectedOrders, setSelectedOrders] = useState<number[]>([]);

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      if (activeTab === 'overview') {
        const res = await fetch('/api/store-manager/stats', { headers });
        if (res.ok) setStats(await res.json());
      } else if (activeTab === 'marketplace') {
        const res = await fetch('/api/store-manager/marketplace-products', { headers });
        if (res.ok) setMarketplaceProducts(await res.json());
      } else if (activeTab === 'settlements') {
        const res = await fetch('/api/store-manager/orders?status=unpaid', { headers });
        if (res.ok) setOrders(await res.json());
      } else if (activeTab === 'invoices') {
        const res = await fetch('/api/store-manager/invoices', { headers });
        if (res.ok) setInvoices(await res.json());
      } else if (activeTab === 'settings') {
        const res = await fetch('/api/store-manager/settings', { headers });
        if (res.ok) setSettings(await res.json());
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSettleOrders = async () => {
    if (selectedOrders.length === 0) return;
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/store-manager/settle-orders', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ orderIds: selectedOrders })
      });
      if (res.ok) {
        setSelectedOrders([]);
        fetchData();
        alert('پرداخت گروهی با موفقیت انجام شد');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/store-manager/settings', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify(settings)
      });
      if (res.ok) {
        alert('تنظیمات با موفقیت ذخیره شد');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const toggleOrderSelection = (id: number) => {
    if (selectedOrders.includes(id)) {
      setSelectedOrders(selectedOrders.filter(oId => oId !== id));
    } else {
      setSelectedOrders([...selectedOrders, id]);
    }
  };

  const navItems = [
    { id: 'overview', label: 'پیشخوان', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'marketplace', label: 'بانک کالا', icon: <Layers className="w-5 h-5" /> },
    { id: 'settlements', label: 'تسویه سفارشات', icon: <Wallet className="w-5 h-5" /> },
    { id: 'invoices', label: 'صورت‌حساب‌ها', icon: <FileText className="w-5 h-5" /> },
    { id: 'settings', label: 'تنظیمات اتصال', icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <div className="flex h-screen bg-slate-50 w-full" dir="rtl">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col h-full shadow-xl z-10">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Store className="text-emerald-400" />
            پنل مدیر فروشگاه
          </h2>
          <p className="text-slate-400 text-xs mt-2 truncate">
            {user?.storeName}
          </p>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                activeTab === item.id 
                  ? 'bg-emerald-600 text-white' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose-400 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            خروج از حساب
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="bg-white px-8 py-5 flex items-center justify-between border-b border-slate-200 shadow-sm z-0">
          <h1 className="text-2xl font-bold text-slate-800">
            {navItems.find(i => i.id === activeTab)?.label}
          </h1>
        </header>

        <div className="flex-1 overflow-auto p-8 relative">
          
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin" />
            </div>
          ) : (
            <>
              {activeTab === 'overview' && stats && (
                <div className="space-y-6 animate-fade-in">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center">
                        <ShoppingCart className="w-7 h-7" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium">تعداد کل سفارشات</p>
                        <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats.totalOrders}</h3>
                      </div>
                    </div>
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <Wallet className="w-7 h-7" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium">پرداختی به پلتفرم</p>
                        <h3 className="text-2xl font-bold text-slate-900 mt-1">
                          {stats.totalPaid?.toLocaleString()} <span className="text-sm font-normal">تومان</span>
                        </h3>
                      </div>
                    </div>
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center">
                        <TrendingUp className="w-7 h-7" />
                      </div>
                      <div>
                        <p className="text-sm text-slate-500 font-medium">سود خالص (تخمینی)</p>
                        <h3 className="text-2xl font-bold text-slate-900 mt-1">
                          {stats.netProfit?.toLocaleString()} <span className="text-sm font-normal">تومان</span>
                        </h3>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'marketplace' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {marketplaceProducts.map(product => (
                      <div key={product.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden flex flex-col group hover:shadow-md transition-shadow">
                        <div className="h-48 bg-slate-100 relative overflow-hidden flex items-center justify-center text-slate-300">
                          {product.images?.length > 0 ? (
                            <img src={product.images[0].url} className="w-full h-full object-cover" alt={product.name} />
                          ) : (
                            <Layers className="w-16 h-16" />
                          )}
                        </div>
                        <div className="p-5 flex-1 flex flex-col">
                          <p className="text-xs font-semibold text-emerald-600 mb-1">{product.supplier?.brandName}</p>
                          <h3 className="font-bold text-slate-800 text-lg mb-2 leading-tight">{product.name}</h3>
                          
                          <div className="mt-auto pt-4 flex items-center justify-between border-t border-slate-100">
                            <div>
                              <p className="text-xs text-slate-500">قیمت پلتفرم</p>
                              <p className="font-bold text-slate-900">
                                {product.finalPrice ? product.finalPrice.toLocaleString() : product.supplierBasePrice.toLocaleString()} <span className="text-[10px] font-normal">تومان</span>
                              </p>
                            </div>
                            <button className="w-10 h-10 rounded-full bg-slate-50 hover:bg-emerald-50 text-slate-400 hover:text-emerald-600 flex items-center justify-center transition-colors">
                              <Plus className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'settlements' && (
                <div className="space-y-6 animate-fade-in">
                  <div className="flex justify-between items-center bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                    <div>
                      <h3 className="font-bold text-slate-800">بدهی‌ها و سفارشات پرداخت‌نشده</h3>
                      <p className="text-sm text-slate-500 mt-1">مبلغ کل انتخاب شده: 
                        <span className="font-bold text-emerald-600 mx-1">
                          {orders.filter(o => selectedOrders.includes(o.id)).reduce((acc, o) => acc + o.totalAmount, 0).toLocaleString()}
                        </span> 
                        تومان
                      </p>
                    </div>
                    <button 
                      onClick={handleSettleOrders}
                      disabled={selectedOrders.length === 0}
                      className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-medium shadow-sm hover:bg-emerald-700 disabled:opacity-50 transition-colors flex items-center gap-2"
                    >
                      <Wallet className="w-4 h-4" />
                      پرداخت گروهی ({selectedOrders.length})
                    </button>
                  </div>

                  <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                    <table className="w-full text-right text-sm">
                      <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                        <tr>
                          <th className="px-6 py-4 w-10">
                            <input 
                              type="checkbox" 
                              className="rounded text-emerald-600 focus:ring-emerald-500"
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedOrders(orders.map(o => o.id));
                                } else {
                                  setSelectedOrders([]);
                                }
                              }}
                              checked={selectedOrders.length === orders.length && orders.length > 0}
                            />
                          </th>
                          <th className="px-6 py-4">سفارش</th>
                          <th className="px-6 py-4">مبلغ (تومان)</th>
                          <th className="px-6 py-4">تاریخ ثبت</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {orders.map(order => (
                          <tr key={order.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4">
                              <input 
                                type="checkbox" 
                                className="rounded text-emerald-600 focus:ring-emerald-500"
                                checked={selectedOrders.includes(order.id)}
                                onChange={() => toggleOrderSelection(order.id)}
                              />
                            </td>
                            <td className="px-6 py-4 font-mono">#{order.id}</td>
                            <td className="px-6 py-4 font-bold">{order.totalAmount.toLocaleString()}</td>
                            <td className="px-6 py-4 text-slate-500 font-mono">{new Date(order.createdAt).toLocaleDateString('fa-IR')}</td>
                          </tr>
                        ))}
                        {orders.length === 0 && (
                          <tr>
                            <td colSpan={4} className="px-6 py-10 text-center text-slate-500">هیچ سفارش پرداخت‌نشده‌ای ندارید.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {activeTab === 'invoices' && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden animate-fade-in">
                  <table className="w-full text-right text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                      <tr>
                        <th className="px-6 py-4">شماره فاکتور</th>
                        <th className="px-6 py-4">مبلغ پرداختی</th>
                        <th className="px-6 py-4">وضعیت</th>
                        <th className="px-6 py-4">تاریخ پرداخت</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {invoices.map(invoice => (
                        <tr key={invoice.id} className="hover:bg-slate-50">
                          <td className="px-6 py-4 font-mono font-bold text-slate-700">INV-{invoice.id}</td>
                          <td className="px-6 py-4 font-bold">{invoice.totalAmount.toLocaleString()} تومان</td>
                          <td className="px-6 py-4">
                            <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">
                              موفق
                            </span>
                          </td>
                          <td className="px-6 py-4 text-slate-500 font-mono">
                            {invoice.paidAt ? new Date(invoice.paidAt).toLocaleDateString('fa-IR') : '-'}
                          </td>
                        </tr>
                      ))}
                      {invoices.length === 0 && (
                        <tr>
                          <td colSpan={4} className="px-6 py-10 text-center text-slate-500">هیچ صورت‌حسابی یافت نشد.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === 'settings' && (
                <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 max-w-2xl animate-fade-in">
                  <h3 className="font-bold text-lg text-slate-800 mb-6">تنظیمات اتصال فروشگاه (API)</h3>
                  <form onSubmit={saveSettings} className="space-y-5">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">نوع پلتفرم فروشگاهی</label>
                      <select 
                        value={settings.platformType || ''}
                        onChange={e => setSettings({...settings, platformType: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="">انتخاب کنید</option>
                        <option value="WOOCOMMERCE">ووکامرس (WooCommerce)</option>
                        <option value="SHOPIFY">شاپایفای (Shopify)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">API Key فروشگاه</label>
                      <input 
                        type="text" 
                        value={settings.apiKey || ''}
                        onChange={e => setSettings({...settings, apiKey: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-left"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">آدرس Webhook</label>
                      <input 
                        type="url" 
                        value={settings.webhookUrl || ''}
                        onChange={e => setSettings({...settings, webhookUrl: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-left"
                        dir="ltr"
                        placeholder="https://yourstore.com/webhook"
                      />
                    </div>
                    <button type="submit" className="w-full bg-emerald-600 text-white font-medium py-3 rounded-xl hover:bg-emerald-700 transition-colors">
                      ذخیره تنظیمات
                    </button>
                  </form>
                </div>
              )}
            </>
          )}

        </div>
      </main>
    </div>
  );
}

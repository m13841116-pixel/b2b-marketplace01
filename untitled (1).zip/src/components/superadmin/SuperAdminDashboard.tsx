import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Users, ShoppingBag, DollarSign, Settings,
  LogOut, ShieldCheck, Activity, Package, Briefcase, 
  CreditCard, Search, Edit2, AlertTriangle, CheckCircle, RefreshCw, X, Eye
} from 'lucide-react';

export default function SuperAdminDashboard({ user, onLogout }: any) {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [showMarginModal, setShowMarginModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [marginData, setMarginData] = useState({ type: 'PERCENTAGE', value: 10 });

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      if (activeTab === 'overview') {
        const res = await fetch('/api/admin/stats', { headers });
        if (res.ok) setStats(await res.json());
      } else if (activeTab === 'products') {
        const res = await fetch('/api/admin/products', { headers });
        if (res.ok) setProducts(await res.json());
      } else if (activeTab === 'suppliers') {
        const res = await fetch('/api/admin/suppliers', { headers });
        if (res.ok) setSuppliers(await res.json());
      } else if (activeTab === 'orders') {
        const res = await fetch('/api/admin/orders', { headers });
        if (res.ok) setOrders(await res.json());
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateMargin = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/admin/products/${selectedProduct.id}/margin`, {
        method: 'PATCH',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ marginType: marginData.type, marginValue: marginData.value })
      });
      if (res.ok) {
        setShowMarginModal(false);
        fetchData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const navItems = [
    { id: 'overview', label: 'پیشخوان', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'suppliers', label: 'تامین‌کنندگان', icon: <Briefcase className="w-5 h-5" /> },
    { id: 'stores', label: 'فروشگاه‌ها', icon: <ShoppingCart className="w-5 h-5" /> },
    { id: 'products', label: 'کاتالوگ کالا', icon: <Package className="w-5 h-5" /> },
    { id: 'orders', label: 'سفارشات کل', icon: <ShoppingBag className="w-5 h-5" /> },
    { id: 'financials', label: 'مالی و تسویه', icon: <DollarSign className="w-5 h-5" /> },
    { id: 'settings', label: 'تنظیمات سیستم', icon: <Settings className="w-5 h-5" /> },
  ];

  return (
    <div className="flex h-screen bg-slate-50 w-full" dir="rtl">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col h-full shadow-xl z-10">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="text-rose-400" />
            پنل مدیر کل
          </h2>
          <p className="text-slate-400 text-xs mt-2 truncate">
            {user?.firstName} {user?.lastName} (Super Admin)
          </p>
        </div>
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                activeTab === item.id 
                  ? 'bg-rose-600 text-white' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-rose-400 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            خروج از حساب
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="bg-white px-8 py-5 flex items-center justify-between border-b border-slate-200 shadow-sm z-0">
          <h1 className="text-2xl font-bold text-slate-800">
            {navItems.find(i => i.id === activeTab)?.label}
          </h1>
        </header>

        <div className="flex-1 overflow-auto p-8 relative">
          
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <RefreshCw className="w-8 h-8 text-rose-500 animate-spin" />
            </div>
          ) : (
            <>
              {activeTab === 'overview' && stats && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 animate-fade-in">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
                      <Briefcase className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-slate-500 font-medium">تامین‌کنندگان</p>
                      <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats.suppliers}</h3>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                      <ShoppingCart className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-slate-500 font-medium">فروشگاه‌ها</p>
                      <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats.stores}</h3>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center">
                      <Package className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-slate-500 font-medium">محصولات فعال</p>
                      <h3 className="text-2xl font-bold text-slate-900 mt-1">{stats.activeProducts}</h3>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center">
                      <DollarSign className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm text-slate-500 font-medium">درآمد پلتفرم</p>
                      <h3 className="text-xl font-bold text-slate-900 mt-1">{stats.totalRevenue.toLocaleString()} <span className="text-xs font-normal">تومان</span></h3>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'products' && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden animate-fade-in">
                  <table className="w-full text-right text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                      <tr>
                        <th className="px-6 py-4">شناسه</th>
                        <th className="px-6 py-4">تامین‌کننده</th>
                        <th className="px-6 py-4">نام محصول</th>
                        <th className="px-6 py-4">قیمت تامین‌کننده</th>
                        <th className="px-6 py-4">سود پلتفرم</th>
                        <th className="px-6 py-4">وضعیت</th>
                        <th className="px-6 py-4">عملیات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {products.map(product => (
                        <tr key={product.id} className="hover:bg-slate-50">
                          <td className="px-6 py-4 font-mono text-slate-500">#{product.id}</td>
                          <td className="px-6 py-4">{product.supplier?.brandName}</td>
                          <td className="px-6 py-4 font-semibold text-slate-800">{product.name}</td>
                          <td className="px-6 py-4 font-bold">{product.supplierBasePrice.toLocaleString()}</td>
                          <td className="px-6 py-4 text-emerald-600 font-bold">
                            {product.marginType ? (
                              product.marginType === 'PERCENTAGE' 
                                ? `%${product.marginValue}` 
                                : `${product.marginValue?.toLocaleString()} ت`
                            ) : '-'}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                              product.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                            }`}>
                              {product.status === 'ACTIVE' ? 'فعال' : 'در انتظار بررسی'}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <button 
                              onClick={() => {
                                setSelectedProduct(product);
                                setShowMarginModal(true);
                                setMarginData({ 
                                  type: product.marginType || 'PERCENTAGE', 
                                  value: product.marginValue || 10 
                                });
                              }}
                              className="text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-indigo-100"
                            >
                              تعیین سود
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === 'suppliers' && (
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden animate-fade-in">
                  <table className="w-full text-right text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                      <tr>
                        <th className="px-6 py-4">شناسه</th>
                        <th className="px-6 py-4">نام تجاری</th>
                        <th className="px-6 py-4">نام کامل</th>
                        <th className="px-6 py-4">موبایل</th>
                        <th className="px-6 py-4">وضعیت</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {suppliers.map(s => (
                        <tr key={s.id} className="hover:bg-slate-50">
                          <td className="px-6 py-4 font-mono text-slate-500">#{s.id}</td>
                          <td className="px-6 py-4 font-bold text-slate-800">{s.brandName}</td>
                          <td className="px-6 py-4">{s.firstName} {s.lastName}</td>
                          <td className="px-6 py-4 font-mono" dir="ltr">{s.mobile}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700`}>
                              {s.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}

        </div>
      </main>

      {/* Margin Setup Modal */}
      {showMarginModal && selectedProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center">
              <h3 className="font-bold text-lg text-slate-800">تعیین حاشیه سود پلتفرم</h3>
              <button 
                onClick={() => setShowMarginModal(false)}
                className="text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 p-2 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-4">
                <p className="text-sm font-semibold text-slate-800">{selectedProduct.name}</p>
                <p className="text-xs text-slate-500 mt-1">قیمت پایه: {selectedProduct.supplierBasePrice.toLocaleString()} تومان</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">نوع محاسبه</label>
                <select 
                  value={marginData.type}
                  onChange={e => setMarginData({...marginData, type: e.target.value})}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none"
                >
                  <option value="PERCENTAGE">درصد از مبلغ پایه</option>
                  <option value="FIXED">مبلغ ثابت (تومان)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">مقدار سود</label>
                <input 
                  type="number"
                  value={marginData.value}
                  onChange={e => setMarginData({...marginData, value: Number(e.target.value)})}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none"
                  dir="ltr"
                />
              </div>

              <div className="p-4 bg-emerald-50 rounded-xl mt-4">
                <p className="text-sm text-emerald-800 font-semibold text-center">
                  قیمت نهایی: {(
                    marginData.type === 'PERCENTAGE' 
                      ? selectedProduct.supplierBasePrice * (1 + marginData.value / 100)
                      : selectedProduct.supplierBasePrice + marginData.value
                  ).toLocaleString()} تومان
                </p>
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  onClick={() => setShowMarginModal(false)}
                  className="flex-1 px-4 py-3 bg-slate-100 text-slate-700 rounded-xl font-medium text-sm hover:bg-slate-200 transition-colors"
                >
                  انصراف
                </button>
                <button 
                  onClick={handleUpdateMargin}
                  className="flex-1 px-4 py-3 bg-rose-600 text-white rounded-xl font-medium text-sm hover:bg-rose-700 transition-colors"
                >
                  ذخیره و انتشار
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Custom icons
const ShoppingCart = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
);
